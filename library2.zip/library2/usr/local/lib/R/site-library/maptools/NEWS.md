# Please note that **maptools** will be retired by the end of 2023, plan transition at your earliest convenience; some functionality will be moved to **sp**.

# Version 1.1-2 (development, rev. 392-397)

* Version check for forthcoming GEOS 3.10

# Version 1.1-1 (2021-03-15, rev. 381-391)

* Upgrade **spatstat**-family reverse dependencies


# Version 1.0-2 (2020-08-24, rev. 371-380)

* New `as.im.RasterLayer()` version

* Update stored **sp** objects

# Version 1.0-1 (2020-05-14, rev. -370)

* Update for `linnet` coercion methods

* Added read support for (very) legacy MAP objects